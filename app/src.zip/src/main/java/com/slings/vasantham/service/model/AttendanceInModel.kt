package com.slings.vasantham.service.model

import com.google.gson.annotations.SerializedName

data class AttendanceInModel(
//    @SerializedName("success") val status: String,
    @SerializedName("data") val message: String
)

