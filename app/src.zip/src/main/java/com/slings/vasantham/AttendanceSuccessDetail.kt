package com.slings.vasantham

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import com.slings.vasantham.MainActivity.Companion.navController
import com.transferwise.sequencelayout.SequenceStep
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.security.AccessController.getContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class AttendanceSuccessDetail : BaseActivity() {

//    private lateinit var _binding: SuccessAttenDetailBinding
    private val client = OkHttpClient()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.success_atten_detail)
//        _binding = SuccessAttenDetailBinding.inflate(LayoutInflater.from(this))
//
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        val attenName = findViewById<TextView>(R.id.atten_name)
        val attenDesgn = findViewById<TextView>(R.id.atten_desgn)
        val textViewCurrentTime = findViewById<TextView>(R.id.textViewCurrentTime)
        val attenLog  = findViewById<AppCompatButton>(R.id.attenLog)
        val home  = findViewById<AppCompatButton>(R.id.home)

        val inTime  = findViewById<SequenceStep>(R.id.inTime)
//        inTime.setTextColor(ContextCompat.getColor(applicationContext, R.color.black))

        val currentTime  = findViewById<SequenceStep>(R.id.currentTime)
//        currentTime.setTextColor(ContextCompat.getColor(applicationContext, R.color.black))

        val outTime  = findViewById<SequenceStep>(R.id.outTime)
//        outTime.setTextColor(ContextCompat.getColor(applicationContext, R.color.black))

        setSupportActionBar(toolbar)
        toolbar.title = "Go Back"

        supportActionBar!!.setDisplayHomeAsUpEnabled(true);
        supportActionBar!!.setDisplayShowHomeEnabled(true);


        try {
            val formBody: RequestBody = FormBody.Builder()
                .add("userId",Util.getPreference(applicationContext,"userId","").toString())
                .add("shiftId", Util.getPreference(applicationContext,
                    "shiftId","")!!)
                .build()
            val request =
                Request.Builder().url(
                    Common.URL+"api/admin/shifttimewithusers").post(formBody).build()
            try {
                val dateFormat = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault())
                val currentTime = dateFormat.format(Date())
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                val json = JSONObject(responseBody)
                 attenName.text = "Hi, "+Util.getPreference(applicationContext
                    .applicationContext,"username","")
                attenDesgn.text = "Welcomes to Vasantham"
                textViewCurrentTime.text = currentTime

                // Set shift time with bold text

            } catch (e: Exception) {
e.printStackTrace()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        attenLog.setOnClickListener {
            navController.navigate(R.id.nav_gallery)
            finish()
        }
        home.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            // Handle the back button press here
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
