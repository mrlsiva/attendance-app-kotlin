package com.slings.vasantham.ui.home

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import cn.pedant.SweetAlert.SweetAlertDialog
import com.slings.vasantham.Common
import com.slings.vasantham.MainActivity
import com.slings.vasantham.R
import com.slings.vasantham.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

      binding.attendanceButton.setOnClickListener {
          val navController = findNavController()
          navController.navigate(R.id.navigation_attendance)
      }

        binding.permissionButton.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.nav_permission)
        }

        binding.applyLeaveButton.setOnLongClickListener{
            binding.usersButton.visibility = View.VISIBLE
            binding.designaButton.visibility = View.VISIBLE
            binding.shiftButton.visibility = View.VISIBLE
            return@setOnLongClickListener true
        }

        binding.applyLeaveButton.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.nav_leave)
          /*  val pDialog = SweetAlertDialog(activity, SweetAlertDialog.NORMAL_TYPE)
            pDialog.titleText = "Coming Soon"
            pDialog.setCancelable(true)
            pDialog.show()*/
        }

        binding.usersButton.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.nav_usersfragment)
        }

        binding.designaButton.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.nav_designfragment)
        }

        binding.shiftButton.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.nav_shiftfragment)
        }
      /*  homeViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }*/
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onResume() {
        super.onResume()
        (activity as MainActivity).toolbar_end_item.visibility = View.GONE
//        if(Common.RedirectTo == "attendanceLog"){
//            val navController = findNavController()
//            navController.navigate(R.id.nav_gallery)
//        }
    }
}