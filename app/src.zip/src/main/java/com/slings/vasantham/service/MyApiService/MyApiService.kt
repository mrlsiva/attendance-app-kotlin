package com.slings.vasantham.service.MyApiService

import com.slings.vasantham.service.model.AttendanceInModel
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query

interface MyApiService {
    @Multipart
    @POST("api/staff/attendance/in")
    fun uploadFile(
        @Part("userId") key1: String?,
        @Part("shiftId") key2: String?,
        @Part("associatedId") key3: String?
//        @Part file: MultipartBody.Part
    ): Call<AttendanceInModel>
}
