package com.slings.vasantham.ui.attendance

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StrictMode
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import com.bumptech.glide.Glide
import com.slings.vasantham.AttendanceSucess
import com.slings.vasantham.BaseActivity
import com.slings.vasantham.Common
import com.slings.vasantham.R
import com.slings.vasantham.Util
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException


class SelfConfirmActivity : BaseActivity() {

    private lateinit var imageView: ImageView
    private val client = OkHttpClient()
    //    lateinit var imageUri: Uri
//    lateinit var imageByteArray: ByteArray
    lateinit var loaderLayout: ConstraintLayout
    lateinit var destFile:File
//    lateinit var progr_per: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.selfie_confirm)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        imageView = findViewById(R.id.imageView)
        val upload = findViewById<Button>(R.id.upload)
        val retake = findViewById<Button>(R.id.retake)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        loaderLayout = findViewById<ConstraintLayout>(R.id.loader_layout)
        setSupportActionBar(toolbar)
        toolbar.title = "Go Back"

        supportActionBar!!.setDisplayHomeAsUpEnabled(true);
        supportActionBar!!.setDisplayShowHomeEnabled(true);
        val sourceFile = File(intent.getStringExtra("imageURL"))
        destFile = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"1.jpg")
        val maxSizeInBytes:Long = 1024 * 1024
        resizeAndCompressImage(sourceFile, destFile,maxSizeInBytes)
        upload.setOnClickListener {
            showProgressDialog()

        }

        retake.setOnClickListener {
            val intent = Intent(this, SelfieAttendance::class.java)
            startActivity(intent)
            finish()
        }

        Glide.with(this)
            .load(intent.getStringExtra("imageURL"))
            .into(imageView);
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            // Handle the back button press here
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }


    private fun showProgressDialog() {
        loaderLayout.visibility = View.VISIBLE
        val handler = Handler(Looper.getMainLooper())
        val backgroundTask1 = Runnable {
            handler.post {
                attendenaceIn()
            }
        }
        handler.postDelayed(backgroundTask1, 800)
    }

    fun excep(title: Unit){
//        val pDialog = SweetAlertDial]'
//                finish()
//            })
//        pDialog.show()
        val alertDialog = AlertDialog.Builder(
            SelfConfirmActivity@this)
        alertDialog.setMessage("Alert")
        alertDialog.setTitle(title.toString())
        alertDialog.setCancelable(true)
        alertDialog.setPositiveButton(
            "OK"
        ) { dialog, which -> }

        alertDialog.create().show()
    }


    fun attendenaceIn() {
        lateinit var response: Response
        val bufferSize = 4096
        val buffer = ByteArray(bufferSize)
        lateinit var json : JSONObject
        val imageFile = File(intent.getStringExtra("imageURL")!!)
        try {
            val mediaType: MediaType = "image/*".toMediaTypeOrNull()
                ?: throw IllegalArgumentException("Invalid media type")
//            val totalFileSize = imageByteArray.size
            var uploadedBytes: Long = 0

            val requestBody: RequestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "userId",
                    Util.getPreference(applicationContext, "userId", "") ?: ""
                )
                .addFormDataPart(
                    "shiftId",
                    Util.getPreference(applicationContext, "shiftId", "") ?: ""
                )
                .addFormDataPart("associatedId", "30000")
                .addFormDataPart("imageUrl", destFile.name,
                    destFile.asRequestBody("image/*".toMediaTypeOrNull())
                )
                .build()

            val request = Request.Builder()
                .url(
                    Common.URL +"api/staff/attendance/in")
                .post(requestBody)
                .build()

            response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                // Handle HTTP error (e.g., response.code())
                throw IOException("HTTP Error: ${response.code}")
            }

        }  catch (e: Exception) {
            // Handle other unexpected exceptions
            Toast.makeText(applicationContext,""+response.body?.string(),Toast.LENGTH_LONG).show()
            if (destFile.exists()) {
                Toast.makeText(applicationContext,"OK "+destFile.absolutePath,Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(applicationContext,"Fail "+destFile.absolutePath,Toast.LENGTH_LONG).show()
            }
            Toast.makeText(applicationContext," "+response.code,Toast.LENGTH_LONG).show()
            Toast.makeText(applicationContext," "+response.message,Toast.LENGTH_LONG).show()
            Toast.makeText(applicationContext," "+e.toString(),Toast.LENGTH_LONG).show()
            excep(e.printStackTrace())
            e.printStackTrace()
        } finally {
//            response?.body?.close() // Close the response body to release resources
            loaderLayout.visibility = View.GONE
            try{
                val responseBody = response.body?.string()
                json = JSONObject(responseBody)
                val data = json.getJSONObject("data")
                val intent = Intent(this, AttendanceSucess::class.java)
                intent.putExtra("lateBy",data.getString("lateBy"))
                startActivity(intent)
                finish()
            }catch (e:Exception) {
                e.printStackTrace()
            }
        }
    }


    fun resizeAndCompressImage(sourceFile: File, destFile: File, maxSizeInBytes: Long) {
        try {
            // Decode the source image file into a Bitmap
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(sourceFile.absolutePath, options)

            // Calculate the inSampleSize to reduce image dimensions
            options.inSampleSize = calculateInSampleSize(options, destFile)

            // Decode the image with the calculated inSampleSize
            options.inJustDecodeBounds = false
            val bitmap = BitmapFactory.decodeFile(sourceFile.absolutePath, options)

            // Compress the image to reduce file size
            val stream = FileOutputStream(destFile)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream) // You can adjust the compression quality as needed
            stream.close()

            println("Image resized and compressed successfully!")
        } catch (e: IOException) {
            e.printStackTrace()
            println("Image resize and compression failed: ${e.message}")
        }
    }

    fun calculateInSampleSize(options: BitmapFactory.Options, destFile: File): Int {
        val maxSize = destFile.length()
        val imageWidth = options.outWidth
        val imageHeight = options.outHeight
        var inSampleSize = 1

        while ((imageWidth * imageHeight) / (inSampleSize * inSampleSize * 2) > maxSize) {
            inSampleSize *= 2
        }

        return inSampleSize
    }
}
