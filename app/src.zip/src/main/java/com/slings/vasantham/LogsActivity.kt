package com.slings.vasantham

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.Gson
import com.slings.vasantham.data.model.AttendanceLogResponse
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody

class LogsActivity : BaseActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MyAdapter
    private lateinit var myArrayList: ArrayList<item>
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_gallery)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(applicationContext)

        // Load the ArrayList from ShredPreferences
//        val myArrayList = MyPreferences.getArrayList(requireActivity().applicationContext)

        try {
            val formBody: RequestBody = FormBody.Builder()
                .add("userId", Util.getPreference(applicationContext,"userId","").toString())
                .build()
            val request =
                Request.Builder().url(
                    Common.URL+"api/staff/attendance/logs/"+
                            Util.getPreference(applicationContext,"userId","").toString()).post(formBody).build()
            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                val gson = Gson()
                val responseBy = gson.fromJson(responseBody, AttendanceLogResponse::class.java)

                val attendanceEntries = responseBy.logs?.data ?: emptyList()
                val adapter = MyAdapter(attendanceEntries)
                recyclerView.adapter = adapter

            } catch (e: Exception) {
                e.printStackTrace()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }
}
