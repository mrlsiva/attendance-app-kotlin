package com.slings.vasantham.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.StrictMode
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.applandeo.materialcalendarview.EventDay
import com.applandeo.materialcalendarview.listeners.OnDayClickListener
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.slings.vasantham.AttendanceSuccessDetail
import com.slings.vasantham.Common
import com.slings.vasantham.LogsActivity
import com.slings.vasantham.MainActivity
import com.slings.vasantham.MyAdapter
import com.slings.vasantham.MyPreferences
import com.slings.vasantham.R
import com.slings.vasantham.Util
import com.slings.vasantham.data.model.AttendanceLogResponse
import com.slings.vasantham.databinding.FragmentGalleryBinding
import com.slings.vasantham.databinding.LogsBinding
import com.slings.vasantham.databinding.ProfileEditBinding
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class ProfileEditFragment : Fragment() {
    private val client = OkHttpClient()
    private var _binding: ProfileEditBinding? = null
    lateinit var dob:String
    lateinit var roldId:String
    lateinit var gender:String
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        _binding = ProfileEditBinding.inflate(inflater, container, false)
        val root: View = binding.root


        try {
            val pDialog = SweetAlertDialog(activity, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.titleText = "Loading"
            pDialog.setCancelable(true)
            pDialog.show()
            val formBody: RequestBody = FormBody.Builder()
                .add("userId", Util.getPreference(requireActivity().applicationContext,"userId","").toString())
                .build()
            val request =
                Request.Builder().url(
                    Common.URL+"api/staff/profile/"+
                            Util.getPreference(requireActivity()
                                .applicationContext, "userId",
                                "")
                                .toString()).get().build()
            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                val json = JSONObject(responseBody)
                if (json.has("success")) {
                    val data = json.getJSONObject("data")
                    binding!!.fnameEt.setText(
                        data.getString("firstName"))
                    binding!!.lastNameEt.setText(
                        data.getString("lastName"))
                    binding!!.designEt.setText(
                        data.getString("roleName"))
                    binding!!.mailEt.setText(
                        data.getString("email"))
                    binding!!.phoneEt.setText(
                        data.getString("mobile"))
                    binding!!.addressEt.setText(
                        data.getString("address"))
                    binding!!.passwordEt.setText(
                        Util.getPreference(requireActivity(),"password",""))
                    binding!!.confPasswordEt.setText(
                                Util.getPreference(requireActivity(),"password",""))
                    dob =  data.getString("DOB")
                    roldId = data.getString("roleId")
                    gender = data.getString("gender")
                    pDialog.dismiss()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                pDialog.dismiss()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


   /*     val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)

        binding!!.calendarview.setOnDayClickListener(object : OnDayClickListener {
            override fun onDayClick(eventDay: EventDay) {
                val intent = Intent(activity, LogsActivity::class.java)
                startActivity(intent)
            }
        })*//*     val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)

        binding!!.calendarview.setOnDayClickListener(object : OnDayClickListener {
            override fun onDayClick(eventDay: EventDay) {
                val intent = Intent(activity, LogsActivity::class.java)
                startActivity(intent)
            }
        })*/

        binding.submitBtn.setOnClickListener{
            try {
                val pDialog = SweetAlertDialog(activity, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.titleText = "Loading"
                pDialog.setCancelable(true)

                pDialog.setOnShowListener {
                    val formBody: RequestBody = FormBody.Builder()
                        .add("firstName", binding!!.fnameEt.text.toString())
                        .add("lastName", binding!!.lastNameEt.text.toString())
                        .add("email",binding!!.mailEt.text.toString())
                        .add("password",binding!!.passwordEt.text.toString())
                        .add("password_confirmation",binding!!.confPasswordEt.text.toString())
                        .add("mobile", binding!!.phoneEt.text.toString())
                        .add("gender", gender)
                        .add("DOB", dob)
                        .add("role",roldId)
                        .add("address", binding!!.addressEt.text.toString())
                        .build()
                    val request =
                        Request.Builder().url(
                            Common.URL+"api/staff/profile/edit/"+
                                    Util.getPreference(requireActivity()
                                        .applicationContext, "userId",
                                        "")
                                        .toString()).post(formBody).build()
                    try {
                        val response = client.newCall(request).execute()
                        val responseBody = response.body?.string()
                        val json = JSONObject(responseBody)
                        pDialog.dismiss()
                        if (json.has("message")) {
                            val pDialog1 = SweetAlertDialog(activity, SweetAlertDialog.NORMAL_TYPE)
                            pDialog1.titleText = json.getString("message")
                            pDialog1.setCancelable(true)
                            pDialog1.setConfirmText("OK")
                                .setConfirmClickListener(SweetAlertDialog.OnSweetClickListener { sweetAlertDialog ->
                                    sweetAlertDialog.dismiss()
                                    requireActivity().supportFragmentManager.popBackStack();
                                })
                            pDialog1.show()
                        }else{
                            val pDialog2 = SweetAlertDialog(activity, SweetAlertDialog.NORMAL_TYPE)
                            pDialog2.titleText = json.getString("error")
                            pDialog2.setCancelable(true)
                            pDialog2.setConfirmText("OK")
                                .setConfirmClickListener(SweetAlertDialog.OnSweetClickListener { sweetAlertDialog ->
                                    val intent = Intent(activity, MainActivity::class.java)
                                    startActivity(intent)
                                    sweetAlertDialog.dismiss()
                                })
                            pDialog2.show()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        pDialog.dismiss()
                    }
                }
                pDialog.show()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}