package com.slings.vasantham

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import kotlinx.coroutines.DelicateCoroutinesApi

@DelicateCoroutinesApi
class AppController : Application() {

//    lateinit var firebaseCrashlytics: FirebaseCrashlytics

    @DelicateCoroutinesApi
    companion object Factory {
        var mInstance: AppController? = null
        fun get(context: Context): AppController = context.applicationContext as AppController

        @Synchronized
        fun getInstance(): AppController? {
            return mInstance
        }
    }

    override fun onCreate() {
        super.onCreate()
//        FirebaseApp.initializeApp(this)
//        firebaseCrashlytics = FirebaseCrashlytics.getInstance()
//        firebaseCrashlytics.setCrashlyticsCollectionEnabled(true)
//        firebaseCrashlytics.setUserId(Util.getPreference(applicationContext,"userId","").toString())
        // Firebase initialization

        mInstance = this
    }

    fun setConnectivityListener(listener: MyReceiver.ConnectivityReceiverListener?) {
        MyReceiver.connectivityReceiverListener = listener
    }
}