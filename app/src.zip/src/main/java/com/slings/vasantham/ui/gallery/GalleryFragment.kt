package com.slings.vasantham.ui.gallery

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.StrictMode
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.applandeo.materialcalendarview.EventDay
import com.applandeo.materialcalendarview.listeners.OnDayClickListener
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.slings.vasantham.AttendanceSuccessDetail
import com.slings.vasantham.Common
import com.slings.vasantham.LogsActivity
import com.slings.vasantham.MyAdapter
import com.slings.vasantham.MyPreferences
import com.slings.vasantham.R
import com.slings.vasantham.Util
import com.slings.vasantham.data.model.AttendanceLogResponse
import com.slings.vasantham.databinding.FragmentGalleryBinding
import com.slings.vasantham.databinding.LogsBinding
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject

class GalleryFragment : Fragment() {

    private var _binding: LogsBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        _binding = LogsBinding.inflate(inflater, container, false)
        val root: View = binding.root
        binding!!.calendarview.setHeaderColor(R.color.dash_back_color)
        binding!!.calendarview.selectedDates
        binding!!.calendarview.setSelectionBackground(R.color.dash_back_color)
      /*  binding!!.calendarview.setOnDayClickListener(object : OnDayClickListener {
            override fun onDayClick(eventDay: EventDay) {
                val intent = Intent(activity, LogsActivity::class.java)
                startActivity(intent)
            }
        })*/

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}