package com.slings.vasantham.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import cn.pedant.SweetAlert.SweetAlertDialog
import com.slings.vasantham.Common
import com.slings.vasantham.MainActivity
import com.slings.vasantham.R
import com.slings.vasantham.Util
import com.slings.vasantham.databinding.ProfileBinding
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject

class ProfileFragment : Fragment() {

    private var _binding: ProfileBinding? = null
    private val client = OkHttpClient()
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = ProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val roundedButton:Button = root.findViewById<Button>(R.id.roundedButton);

        roundedButton.setOnClickListener(View.OnClickListener { view ->
            MainActivity.navController.navigate(R.id.nav_profileeditfragment)
        })

        try {
            val pDialog = SweetAlertDialog(activity, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.titleText = "Loading"
            pDialog.setCancelable(true)
            pDialog.show()
            val formBody: RequestBody = FormBody.Builder()
                .add("userId", Util.getPreference(requireActivity().applicationContext,"userId","").toString())
                .build()
            val request =
                Request.Builder().url(
                    Common.URL+"api/staff/profile/"+
                            Util.getPreference(requireActivity()
                                .applicationContext, "userId",
                                "")
                    .toString())
                    .get()
                    .build()
            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                val json = JSONObject(responseBody)
                if (json.has("success")) {
                 val data = json.getJSONObject("data")
                    binding!!.profileName.text =
                        data.getString("firstName")+" "+
                                data.getString("lastName")
                    binding!!.profileDesign.text =
                        data.getString("roleName")
                    binding!!.profileEmail.text =
                        data.getString("email")
                    binding!!.profileMobileNo.text =
                        data.getString("mobile")
                    binding!!.profileAddress.text =
                        data.getString("address")
                    binding!!.profilePassword.text =
                        data.getString("password")
                    pDialog.dismiss()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                pDialog.dismiss()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
       /* val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)
ProfileFragment
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)


        binding!!.calendarview.setOnDayClickListener(object : OnDayClickListener {
            override fun onDayClick(eventDay: EventDay) {
                val intent = Intent(activity, LogsActivity::class.java)
                startActivity(intent)
            }
        })*/

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}